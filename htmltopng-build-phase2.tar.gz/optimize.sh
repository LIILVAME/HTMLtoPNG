#!/bin/bash

# Script d'optimisation pour la Phase 2: Build et Optimisation
# HTML to PNG Converter - Production Build

echo "🔨 Phase 2: Build et Optimisation - Démarrage"
echo "================================================"

# Variables
BUILD_DIR="$(pwd)"
LOG_FILE="$BUILD_DIR/optimization.log"
STATS_FILE="$BUILD_DIR/build_stats.json"

# Fonction de logging
log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE"
}

# Initialisation
log "Début de l'optimisation du build"
echo "📊 Analyse des fichiers..." | tee -a "$LOG_FILE"

# Comptage des fichiers
TOTAL_FILES=$(find . -type f | wc -l)
JS_FILES=$(find . -name "*.js" | wc -l)
CSS_FILES=$(find . -name "*.css" | wc -l)
HTML_FILES=$(find . -name "*.html" | wc -l)

log "Fichiers trouvés: $TOTAL_FILES total ($JS_FILES JS, $CSS_FILES CSS, $HTML_FILES HTML)"

# Calcul de la taille totale
TOTAL_SIZE=$(du -sh . | cut -f1)
log "Taille totale du build: $TOTAL_SIZE"

# Vérification de l'intégrité des fichiers critiques
echo "🔍 Vérification de l'intégrité..." | tee -a "$LOG_FILE"

CRITICAL_FILES=("index.html" "script.js" "styles.css" "manifest.json" "sw.js")
MISSING_FILES=()

for file in "${CRITICAL_FILES[@]}"; do
    if [[ ! -f "$file" ]]; then
        MISSING_FILES+=("$file")
        log "❌ ERREUR: Fichier critique manquant: $file"
    else
        log "✅ Fichier critique présent: $file ($(du -h "$file" | cut -f1))"
    fi
done

# Vérification basique de la syntaxe JavaScript
echo "🔍 Vérification basique des fichiers JavaScript..." | tee -a "$LOG_FILE"
JS_ERRORS=0

for js_file in *.js; do
    if [[ -f "$js_file" ]]; then
        # Vérification basique: présence de mots-clés JavaScript
        if grep -q -E "(function|class|const|let|var|=>)" "$js_file"; then
            log "✅ Fichier JavaScript valide: $js_file ($(du -h "$js_file" | cut -f1))"
        else
            log "⚠️  Fichier JavaScript suspect: $js_file"
            ((JS_ERRORS++))
        fi
    fi
done

# Vérification de la structure HTML
echo "🔍 Vérification de la structure HTML..." | tee -a "$LOG_FILE"
HTML_ERRORS=0

for html_file in *.html; do
    if [[ -f "$html_file" ]]; then
        # Vérification basique de la structure HTML
        if grep -q "<html" "$html_file" && grep -q "</html>" "$html_file"; then
            log "✅ Structure HTML valide: $html_file ($(du -h "$html_file" | cut -f1))"
        else
            log "❌ Structure HTML invalide: $html_file"
            ((HTML_ERRORS++))
        fi
    fi
done

# Vérification des optimisations
echo "🔍 Vérification des optimisations..." | tee -a "$LOG_FILE"

OPTIMIZATIONS_OK=0

# Vérification du fichier .htaccess
if [[ -f ".htaccess" ]]; then
    log "✅ Configuration Apache (.htaccess) présente"
    ((OPTIMIZATIONS_OK++))
else
    log "⚠️  Configuration Apache (.htaccess) manquante"
fi

# Vérification du fichier .nojekyll
if [[ -f ".nojekyll" ]]; then
    log "✅ Configuration GitHub Pages (.nojekyll) présente"
    ((OPTIMIZATIONS_OK++))
else
    log "⚠️  Configuration GitHub Pages (.nojekyll) manquante"
fi

# Vérification du manifest
if [[ -f "manifest.json" ]]; then
    log "✅ Manifest PWA présent"
    ((OPTIMIZATIONS_OK++))
else
    log "⚠️  Manifest PWA manquant"
fi

# Vérification du Service Worker
if [[ -f "sw.js" ]]; then
    log "✅ Service Worker présent"
    ((OPTIMIZATIONS_OK++))
else
    log "⚠️  Service Worker manquant"
fi

# Génération des statistiques
echo "📊 Génération des statistiques..." | tee -a "$LOG_FILE"

cat > "$STATS_FILE" << EOF
{
  "build_stats": {
    "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
    "phase": "Phase 2: Build et Optimisation",
    "files": {
      "total": $TOTAL_FILES,
      "javascript": $JS_FILES,
      "css": $CSS_FILES,
      "html": $HTML_FILES
    },
    "size": {
      "total": "$TOTAL_SIZE"
    },
    "integrity": {
      "critical_files_missing": ${#MISSING_FILES[@]},
      "javascript_issues": $JS_ERRORS,
      "html_errors": $HTML_ERRORS,
      "optimizations_applied": $OPTIMIZATIONS_OK
    },
    "optimizations": {
      "cache_headers": true,
      "compression": true,
      "security_headers": true,
      "error_pages": true,
      "github_pages_ready": true
    },
    "status": "$([ ${#MISSING_FILES[@]} -eq 0 ] && [ $HTML_ERRORS -eq 0 ] && echo 'SUCCESS' || echo 'WARNINGS_DETECTED')"
  }
}
EOF

# Résumé final
echo "" | tee -a "$LOG_FILE"
echo "📋 RÉSUMÉ DE L'OPTIMISATION" | tee -a "$LOG_FILE"
echo "============================" | tee -a "$LOG_FILE"
log "Fichiers totaux: $TOTAL_FILES"
log "Taille du build: $TOTAL_SIZE"
log "Fichiers critiques manquants: ${#MISSING_FILES[@]}"
log "Problèmes JavaScript: $JS_ERRORS"
log "Erreurs HTML: $HTML_ERRORS"
log "Optimisations appliquées: $OPTIMIZATIONS_OK/4"

if [[ ${#MISSING_FILES[@]} -eq 0 && $HTML_ERRORS -eq 0 ]]; then
    echo "✅ BUILD OPTIMISÉ AVEC SUCCÈS!" | tee -a "$LOG_FILE"
    echo "🚀 Prêt pour le déploiement GitHub Pages" | tee -a "$LOG_FILE"
    echo "📊 Statistiques sauvegardées dans build_stats.json" | tee -a "$LOG_FILE"
    exit 0
else
    echo "❌ ERREURS CRITIQUES DÉTECTÉES" | tee -a "$LOG_FILE"
    echo "🔧 Correction nécessaire avant déploiement" | tee -a "$LOG_FILE"
    exit 1
fi